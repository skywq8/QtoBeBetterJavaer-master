---
category:
  - 知识库搭建
tag:
  - 知识库搭建
title: 购买云服务器
shortTitle: 购买云服务器
---

总之一句话，“**老客不如狗，新客是真香**”~

有些买过服务器的小伙伴，已经把个人博客整起来了，这里推荐三个给大家欣赏一下（可以直接复制图片下的链接到浏览器地址栏），真的惊艳~

![http://zhuoke.xyz/](https://cdn.tobebetterjavaer.com/tobebetterjavaer/images/szjy/tobebetterjavaer-beian-7379f1e6-6967-447e-9f62-e19ba1af927d.png)

**打开这个网站的时候要小心，小心差点鼻血流出来**~~~~

![https://laifeng.xyz/about_me/](https://cdn.tobebetterjavaer.com/tobebetterjavaer/images/szjy/tobebetterjavaer-beian-182e856b-771c-4445-b508-dbabded164f2.png)

![https://www.zm211314.top/](https://cdn.tobebetterjavaer.com/tobebetterjavaer/images/szjy/tobebetterjavaer-beian-67d47432-e571-48ad-8c12-4638264d82bf.png)

不得不说，都是二哥的铁粉，个人博客还不忘夸二哥一番。

😜

之前买阿里云服务器的时候，很多小伙伴就强烈要求二哥出一些教程把饭喂到嘴里，因为是第一次——玩服务器~

我出过一期视频，讲了程序员拥有一台云服务器能做哪些很酷的事情？

![](https://cdn.tobebetterjavaer.com/tobebetterjavaer/images/szjy/buy-cloud-server-ae3255d4-1166-440c-b1a4-defb298f8b0c.png)

>视频地址戳这里：[https://www.bilibili.com/video/BV1nb4y187rU/](https://www.bilibili.com/video/BV1nb4y187rU/)

![](https://cdn.tobebetterjavaer.com/tobebetterjavaer/images/gongzhonghao.png)
