# 新版声明

```text
《上海交通大学生存手册》在十二年来被无数交大学子传阅，本次更新内容请参见项目Github repo的README文件，第二版编委欢迎读者于[https://github.com/SurviveSJTU/SurviveSJTUMan](https://github.com/SurviveSJTU/SurviveSJTUManual) 提出issue与pull request我们讨论并协助优化本手册内容。第二版编委在此衷心感谢初版手册编委学长学姐们的付出，希望我们能将这份对新生的关怀不断传递下去，旧版声明中的内容对第二版手册依然有效。

                                                                                                                                                                  本书编委会
```

