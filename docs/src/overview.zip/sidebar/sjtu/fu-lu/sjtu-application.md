# 本科毕业之后

我们将交大学生**毕业之后**的出路经验分享包括出国、直博、保研、考研与就业共五项独立为SJTU-Application项目，详情请参考[https://survivesjtu.github.io/SJTU-Application/\#/](https://survivesjtu.github.io/SJTU-Application/#/)

