---
home: true
layout: BlogHome
icon: home
title: 博客
heroImage: /itwanger.png
heroText: 沉默王二的技术博客
heroFullScreen: false
tagline: 技术文通俗易懂，吹水文风趣幽默。
projects:
  - icon: project
    name: 进阶之路
    desc: 二哥的Java进阶之路
    link: /home.md

  - icon: link
    name: 知识星球
    desc: 二哥的编程学习圈子
    link: /zhishixingqiu/

  - icon: book
    name: Java电子书下载
    desc: Java程序员常读书单，附下载地址
    link: /download/java.md

  - icon: article
    name: 学习路线
    desc: CS 学习指南
    link: /xuexiluxian/

  - icon: friend
    name: 面渣逆袭
    desc: 面试找工作前必刷
    link: /sidebar/sanfene/nixi.md

  - icon: zhongyaotishi
    name: 破解合集
    desc: 程序员常用工具聚集地
    link: /nice-article/itmind/

---
