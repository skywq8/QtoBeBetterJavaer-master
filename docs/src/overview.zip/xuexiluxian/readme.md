---
title: Java、C语言、C++、Python、Go 语言、操作系统、前端、算法和数据结构、蓝桥杯、大数据、Android、MySQL、Redis、.NET、Linux学习路线🔥
shortTitle: 计算机专业&编程语言学习路线（全）
category:
  - 学习路线
tag:
  - 学习路线
description: Java、C语言、C++、Python、Go 语言、操作系统、前端、算法和数据结构、蓝桥杯、大数据、Android、MySQL、Redis、.NET、Linux等硬核学习路线，欢迎收藏品鉴！
head:
  - - meta
    - name: keywords
      content: CS,学习路线,编程,计算机专业,程序员,Java,C语言,Python,C++,前端,Go 语言,数据结构,算法,蓝桥杯,大数据,操作系统,安卓,android,mysql,redis,.NET,Linux
---


* [Java学习路线一条龙版（建议收藏🔥）](java/yitiaolong.md)
* [Java并发编程学习路线（建议收藏🔥）](java/thread.md)
* [Java虚拟机学习路线（建议收藏🔥）](java/jvm.md)
* [MySQL 学习路线（建议收藏🔥）](mysql.md)
* [Redis 学习路线（建议收藏🔥）](redis.md)
* [C语言学习路线（建议收藏🔥）](c.md)
* [C++学习路线（建议收藏🔥）](ccc.md)
* [Python学习路线（建议收藏🔥）](python.md)
* [Go语言学习路线（建议收藏🔥）](go.md)
* [操作系统学习路线（建议收藏🔥）](os.md)
* [前端学习路线（建议收藏🔥）](qianduan.md)
* [算法和数据结构学习路线（建议收藏🔥）](algorithm.md)
* [蓝桥杯学习路线（建议收藏🔥）](lanqiaobei.md)
* [大数据学习路线（建议收藏🔥）](bigdata.md)
* [Android 安卓学习路线（建议收藏🔥）](android.md)
* [.NET 学习路线（建议收藏🔥）](donet.md)
* [Linux 学习路线（建议收藏🔥）](linux.md)
 