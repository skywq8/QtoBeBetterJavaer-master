# 学习建议

>不知道学什么？不知道该怎么学？答案都在这里。

- [如何阅读《深入理解计算机系统》这本书？](/xuexijianyi/read-csapp.md)
- [电子信息工程最好的出路的是什么？](/xuexijianyi/electron-information-engineering.md)